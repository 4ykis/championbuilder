function Custom() {
    return {
        //LVL INPUT CHANGE CHECKER
        lvlChange: function () {
            $('.js-level').on('change',function() {
                var value = $(this).val();
                if( value > 18 ){ $(this).val('18'); }
                if( value < 1)  { $(this).val('1');  }
                js.calcAll();
                js.calcSpell();
            });
        },
        //TAKE LVL NOW
        lvl: function () {
            return  $('.js-level').val();
        },
        //CREATE ITEMS IN BLOCK
        createItemBlock: function (){
            $.each($items ,function () {
                var block = '<img src="'+this.icon+'" alt="'+this.name+'"  title="'+this.name+'" data-id="'+this.id+'">';
                $('.js-items-all').append(block);
            });
            setTimeout(function(){
                $('.js-items-all img').eq(0).click();
            },10);

        },
        //CALC SPELL
        calcSpell:function(){
            var s = $champ.skills;
            //pass
            // var pass =
            var lvl = js.lvl();
            for(var i=0;i<s.p.lvl.length;i++){
                if( lvl >= s.p.lvl[i] ){
                    var lvlScale = i;
                }
            }
            console.log(s.p.base[lvlScale]);
        },
        //take item id by name of passive
        takeItemIdByPass: function(elem){
            var z;
            $.each($pass.id,function(){
                if(this.pass == elem ){
                    z = this.id;
                }
            });
            return z;
        },
        //display all params
        paramsDisplay: function (ap,hp,lfs,mp,ad,mr,ms,hp5,mp5,arm,as,crit,cd) {
            $('.js-param-ap').text(ap);
            $('.js-param-hp').text(hp);
            $('.js-param-lfs').text(lfs);
            $('.js-param-mp').text(mp);
            $('.js-param-ad').text(ad);
            $('.js-param-mr').text(mr);
            $('.js-param-ms').text(ms);
            $('.js-param-hp5').text(hp5);
            $('.js-param-mp5').text(mp5);
            $('.js-param-arm').text(arm);

            if(as > 2.5){
                var oas =  as - 2.5;
                $('.js-param-as').text('2.5 !overcap in '+oas+' !');
            } else {
                $('.js-param-as').text(as);
            }
            if(crit > 100){
                var ocrit = $criti+$critb+$critr - 100;
                $('.js-param-crit').text('100% overcap in '+ocrit+'%');
            } else {
                $('.js-param-crit').text(crit + '%');
            }

            if(cd > 40){
                var ocd = $cdi+$cdb+$cdr - 40;
                $('.js-param-cd').text('100% overcap in '+ocd+'%');
            } else {
                $('.js-param-cd').text(cd + '%');
            }
        },
        //ITEM DESCRIPTION
        thisItemTab: function (img) {
            var id = img.attr('data-id');
            var buildfromimg='',
                buildtoimg='',
                newBlock='',
                numb,numb1;
            /* Block with description !!!! NED REWORK !!!!!*/
            newBlock = '<h5>' + $items[id].name + '</h5>'
            + '<p class="filter-price">Price: <span>' + $items[id].price + '</span> g.</p><ul class="filter-params">'
            + '<li>Ability power: <span>' + $items[id].ap + '</span></li></ul>';

            /* add passives */
            if($items[id].pass.length > 0){
                for(var j=0; j<$items[id].pass.length;j++){
                    newBlock += '<div class="filter-passive">' + $items[id].pass[j] + '</div>';
                }
            }
            /* add items building from */
            if($items[id].build.length > 0){
                for (var i=0;i<$items[id].build.length;++i){
                    numb = $items[id].build[i];
                    buildfromimg += '<img src="'+$items[numb].icon+'" alt="'+$items[numb].name+'"  title="'+$items[numb].name+'" data-id="'+$items[numb].id+'">'
                }
            }
            /* add items building to */
            if($items[id].buildTo.length > 0){
                for (var k=0;k<$items[id].buildTo.length;++k){
                    numb1 = $items[id].buildTo[k];
                    buildtoimg += '<img src="'+$items[numb1].icon+'" alt="'+$items[numb1].name+'"  title="'+$items[numb1].name+'" data-id="'+$items[numb1].id+'">'
                }
            }
            /* adding all */
            $('.js-add-item').attr('data-id',id);
            $('.js-build-from').html(buildfromimg);
            $('.js-build-to').html(buildtoimg);
            $('.js-item-descr').html(newBlock);
        },
        // ADD ITEM FUNCTION
        addItemOnMe: function (iditem) {
            var id =  iditem.attr('data-id');
            var free = $('.item-on-me:not(".active")');
            var flag = true;
            if(id !== undefined){
                if(free.length > 0){
                    free.eq(0).addClass('active');
                    free.eq(0).find('img').attr('src',$items[id].icon);
                    free.eq(0).attr('data-item-id',$items[id].id);
                }
            }
            //add passives
            if( $items[id].pass.length > 0 ){
                var passBlock = '';
                if($('.one-my-pass').length>0) {
                    for (var i = 0; i < $('.one-my-pass').length; i++) {
                        if ($('.one-my-pass').eq(i).attr('data-id') == $items[id].id) {
                            flag = false
                        }
                    }
                }
                if(flag){
                    for(var j=0; j<$items[id].pass.length;j++){
                        passBlock += '<div class="one-my-pass" data-id="'+$items[id].id+'">'+$items[id].pass[j]+'</div>'
                    }
                }
                $('.my-item-pass').append(passBlock);
            }
        },
        //DELETE ITEM FUNCTION
        deleteItemOnMe: function (thisitem) {
            var id = thisitem.attr('data-item-id');
            var blck =  $('.js-items-on-me .item-on-me');
            var flag = true;
            thisitem.removeClass('active');
            thisitem.attr('data-item-id','');
            thisitem.find('img').attr('src',$defitem);

            for (var i = 0; i <blck.length; i++) {
                if(blck.eq(i).attr('data-item-id').length > 0){
                    if (blck.eq(i).attr('data-item-id') == $items[id].id) {
                        flag = false;
                    }
                }
            }
            if(flag){
                $('.one-my-pass[data-id="'+$items[id].id+'"]').remove();
            }

        },
        //CALCULATE BASE PARAMS AND LVL
        calcBasicParams: function () {
            $apb=$hpb=$mpb=$hp5b=$mp5b=$adb=$asb=$armb=$mrb=$msb=$lfsb=$critb=$cdb=0; //all params global
            var lvl = js.lvl() - 1;

            bs = $champ.base;
            $apb = 0;
            $hpb = Math.round( bs.hp+(lvl*bs.lvlhp) );
            $mpb = Math.round( bs.mp+(lvl*bs.lvlmp) );
            $mrb  = Math.round( bs.mr+(lvl*bs.lvlmr) );
            $armb  = Math.round( bs.arm+(lvl*bs.lvlarm) );
            $asb  = lvl*bs.lvlas;

            $hp5b = bs.hp5+(lvl*bs.lvlhp5);
            $mp5b = bs.mp5+(lvl*bs.lvlmp5);

        },
        //CALCULATE PARAMS FROM ITEM
        calcItemParams:function () {

            var thisitem = $('.js-items-on-me .item-on-me');
            var arrItem = [];

            //take all id in array
            for(var i=0 ; i<thisitem.length ; ++i){
                if(thisitem.eq(i).hasClass('active')){
                    var thisid = thisitem.eq(i).attr('data-item-id');
                    if(thisid.length>0){
                        arrItem.push(thisid);
                    }
                }
            }
            $api=$hpi=$mpi=$hp5i=$mp5i=$adi=$asi=$armi=$mri=$msi=$lfsi=$criti=0;
            var rabadon = false;
            var gold = 0;
            //calc params
            for(var j=0; j<arrItem.length;j++){
                var id = arrItem[j];
                $api   += $items[id].ap;
                $hpi   += $items[id].hp;
                $hp5i  += $items[id].hp5;
                $mpi   += $items[id].mp;
                $mp5i  += $items[id].mp5;
                $adi   += $items[id].ad;
                $asi   += $items[id].as;
                $armi  += $items[id].arm;
                $mri   += $items[id].mr;
                $msi   += $items[id].ms;
                $criti += $items[id].crit;
                $lfsi  += $items[id].lfs;
                gold   += $items[id].price;

            }

          $('.js-price').text(gold);
        },
        //CALCULATE ALL PARAMS
        calcAll:function () {
            js.calcItemParams();
            // js.calcRunesParams() //funct котра рахуватиме прибавку рун
            js.calcBasicParams(); //funct котра рахуватиме прибавку базових статів (від лвла)


            var thisitem = $('.js-items-on-me .item-on-me');
            var arrItem = [];
            var arrPass = [];
            var  hp  = $hpi+$hpb+$hpr,
                 ap  = $api+$apb+$apr,
                 lfs = $lfsi+$lfsb+$lfsr,
                 mp  = $mpi+$mpb+$mpr,
                 ad  = $adi+$adb+$adr,
                 mr  = $mri+$mrb+$mrr,
                 ms  = $msi+$msb+$msr,
                 hp5 = Math.round(($hp5i+$hp5b+$hp5r)*10)/10,
                 mp5 = $mp5i+$mp5b+$mp5r,
                 arm = $armi+$armb+$armr,
                 as  = Math.round(($baseAS+ ($baseAS*($asi+$asb+$asr)))*1000)/1000,
                crit = $criti+$critb+$critr,
                  cd = $cdi+$cdb+$cdr;

            var passItems = $('.my-item-pass .one-my-pass');
            var passID;

            //take all id in array
            for(var i=0 ; i<thisitem.length ; ++i){
                if(thisitem.eq(i).hasClass('active')){
                    var thisid = thisitem.eq(i).attr('data-item-id');
                    if(thisid.length>0){
                        arrItem.push(thisid);
                    }
                }
            }
            for(var j=0; j<arrItem.length;j++){
                var id = arrItem[j];
                if($items[id].uniq){
                    $.each($pass.id,function(){
                        // console.log( this.pass );
                        if( this.id == id ){
                            var flag = true;
                            for (var arri=0;arri < arrPass.length;arri++){
                                if(arrPass[arri] === this.pass){
                                    flag = false;
                                }
                            }
                            if(flag){
                                arrPass.push(this.pass);
                            }
                        }
                    });
                }
            }

            for(j=0;j<arrPass.length;j++){
                //rabadon
                if(arrPass[j] == 'rabadon'){
                    var rabadon = ap*0.35;
                    ap = Math.round(rabadon + ap);
                    passID = js.takeItemIdByPass(arrPass[j]);
                    console.log(passID);
                    for (var k=0;k<passItems.length;k++){
                        if(passItems.eq(k).data('id') === passID ){
                            passItems.eq(k).find('span').text('(Add you '+Math.round(rabadon)+' ap)');
                        }
                    }
                }
            }
            js.paramsDisplay (ap,hp,lfs,mp,ad,mr,ms,hp5,mp5,arm,as,crit,cd);
        }
    }
}


var js = new Custom();
// .responseJSON
js.lvlChange();


var c = $.getJSON("../assets/json/champions/" + name + ".json");
var i = $.getJSON("../assets/json/items/items.json");
var r = $.getJSON("../assets/json/runes/runes.json");


/* kostul' goda blyat' */
c.success(function (){i.success(function () {r.success(function () {

    /*VARIABLES GLOBAL*/
    $champ   = c.responseJSON; //champ
    $items   = i.responseJSON.item; //all items
    $pass    = i.responseJSON.pass; //all unique passives
    $runes   = r.responseJSON; //runes
    $api=$hpi=$mpi=$hp5i=$mp5i=$adi=$asi=$armi=$mri=$msi=$lfsi=$criti=$cdi=0; //all params global
    $apb=$hpb=$mpb=$hp5b=$mp5b=$adb=$asb=$armb=$mrb=$msb=$lfsb=$critb=$cdb=0; //all params global
    $apr=$hpr=$mpr=$hp5r=$mp5r=$adr=$asr=$armr=$mrr=$msr=$lfsr=$critr=$cdr=0; //all params global
    $defitem = 'assets/img/items/dorans-ring.gif'; //заглушка
    $baseAS = $champ.base.as;
    /* all function */
    js.createItemBlock();

    //tab work on JSON
    $('.js-items-img img').on('click',function () {
        js.thisItemTab($(this));
    });


    //* ADDING ITEMS
    //on double click
    $('.js-items-img img').dblclick(function(){
        js.addItemOnMe($(this));
        js.calcAll();
    });
    // on button
    $('.js-add-item').on('click',function () {
        js.addItemOnMe($(this));
        js.calcAll();
    });


    //* DELETING ITEMS
    $('.item-on-me').on('click',function () {
        js.deleteItemOnMe($(this));
        js.calcAll();
    });

    /* end all */

});});});

$(document).ready(function(){
    js.lvlChange();


});



/* mb ill need this*/

// $.each(items.ap ,function () {
    // if(this.build.length > 0){
    //     // console.log('length:',this.build.length);
    //     for (var i=0;i<this.build.length;++i){
    //         var numb = this.build[i];
    //         // console.log('this:',numb,items.ap[numb-1]);
    //         buildFrom += items.ap[numb].name;
    //         if(i !== this.build.length-1){
    //             buildFrom +=' ,';
    //         }
    //     }
    // }
    // if(this.buildTo.length > 0){
    //     // console.log('length:',this.build.length);
    //     for (var k=0;k<this.buildTo.length;++k){
    //         var numb = this.buildTo[k];
    //         // console.log('this:',numb);
    //         buildTo += items.ap[numb].name;
    //         if(k !== this.build.length-1){
    //             buildTo +=' ,';
    //         }
    //     }
    // }
// });
