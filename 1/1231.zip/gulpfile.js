/**
 * Created by eugene on 9.12.15.
 * 
 * watcher -> sudo npm install --save-dev gulp-watch
 * sass -> sudo npm install --save-dev gulp-sass 
 * cssmin -> sudo npm install --save-dev gulp-cssmin
 * rename -> sudo npm install --save-dev gulp-rename
 * imagemin -> sudo npm install --save-dev gulp-imagemin
 * uglify js -> sudo npm install --save-dev gulp-uglify
 * concat js -> sudo npm install --save-dev gulp-concat
 * livereload -> sudo npm install --save-dev gulp-livereload
 * gutil -> sudo npm install --save-dev gulp-util
 * 
 */

var gulp = require('gulp'),
    sass = require('gulp-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    cssmin = require('gulp-cssmin'),
    rename = require('gulp-rename'),
    browserSync = require('browser-sync').create(),
    uglify = require('gulp-uglify'),
    concat = require('gulp-concat'),
    gutil = require('gulp-util');
    

//=================================================
gulp.task('default', [ 'sass', 'watch']);

gulp.task('concatscripts', [ 'uglifyjs', 'concatjs']);

gulp.task('sass', function(){
    return gulp.src('assets/scss/**/*.scss')
        .pipe(sass().on('error', function(e) {
            gutil.log(e);
            this.emit('end');
        })) // Using gulp-sass
        .pipe(autoprefixer({
            browsers: ['last 3 versions'],
            cascade: false
        }))
        .pipe(gulp.dest('assets/css/'))
});

gulp.task('watch',function() {
    browserSync.init({
        server: "./"
    });
    
    gulp.watch([
        'assets/scss/base/*.scss',
        '*.html',
        'assets/scss/layouts/*.scss',
        'assets/scss/tools/*.scss',
        'assets/scss/style.scss'
    ], ['sass', 'cssmin']);
});

gulp.task('cssmin', ['sass'], function () {
    gulp.src('assets/css/style.css')
        .pipe(cssmin())
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('assets/css/compressed'))
        .pipe(browserSync.stream());
});

// ==================================================================== //

gulp.task('concatvendor', function() {
    return gulp.src([
        'assets/js/vendor/modernizr.custom.js',
        'assets/js/vendor/imagesloaded.pkgd.min.js',
        'assets/js/vendor/masonry.pkgd.min.js',
        'assets/js/vendor/cbpGridGallery.js',
        'assets/js/vendor/books1.js',
        'assets/js/vendor/classie.js'
        
    ])
        .pipe(concat('vendor.js'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('assets/js/vendor'));
});

gulp.task('concatjs', ['uglifyjs'], function() {
    return gulp.src([
        'assets/js/vendor/vendor.min.js',
        'assets/js/compressed/min/giftcard.js'
    ])
        .pipe(concat('giftcard-custom.js'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(gulp.dest('assets/js/'));
});

gulp.task('concatcss', function() {
    return gulp.src([
        'assets/css/vendor/bootstrap/**/*.css',
        'assets/css/vendor/slick-1.5.7/**/*.css',
        'assets/css/vendor/jquery-ui.min.css'
    ])
        .pipe(concat('vendor.css'))
        .pipe(gulp.dest('assets/css/compressed'));
});

// ==================================================================== //

gulp.task('images', function() {
    gulp.src('assets/img/**/*')
        .pipe(imagemin())
        .pipe(gulp.dest('assets/img/compressed'));

});

gulp.task('uglifyjs', function() {
    return gulp.src('assets/js/giftcard.js')
        .pipe(uglify())
        .pipe(gulp.dest('assets/js/compressed/min'));
});













